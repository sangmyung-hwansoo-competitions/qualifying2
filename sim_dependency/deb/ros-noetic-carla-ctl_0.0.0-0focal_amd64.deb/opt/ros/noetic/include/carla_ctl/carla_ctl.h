#ifndef CARLA_CTL_H
#define CARLA_CTL_H

#include <carla/client/ActorBlueprint.h>
#include <carla/client/BlueprintLibrary.h>
#include <carla/client/Client.h>
#include <carla/client/Map.h>
#include <carla/client/Sensor.h>
#include <carla/client/Vehicle.h>
#include <carla/client/World.h>
#include <carla/geom/Transform.h>
#include <carla/sensor/data/Image.h>
#include <carla/sensor/data/LidarMeasurement.h>
#include <carla/sensor/data/IMUMeasurement.h>
#include <carla/Time.h>
#include <boost/pointer_cast.hpp>

#include <functional>
#include <memory>
#include <string>
#include <vector>
#include <chrono>
#include <thread>
#include <map>

namespace cc = carla::client;
namespace cg = carla::geom;
namespace cs = carla::sensor;
namespace csd = carla::sensor::data;

class CarlaCtl {
public:
    CarlaCtl(const std::string& host, uint16_t port) {
        client_ = boost::make_shared<cc::Client>(host, port);
        client_->SetTimeout(carla::time_duration::seconds(30));
        world_ = boost::make_shared<cc::World>(client_->GetWorld());
        blueprint_library_ = world_->GetBlueprintLibrary();
    }

    ~CarlaCtl() {}

    void LoadWorld() 
    {
        client_->GetWorld();
    }

    void LoadWorld(const std::string& map_name) 
    {
        client_->LoadWorld(map_name);
    }

    void ApplyWorldSettings(carla::rpc::EpisodeSettings settings) 
    {
        world_->ApplySettings(settings);
    }

    void RecordStart(std::string name)
    {
        record_status = true;
        client_->StartRecorder(name);
    }

    void RecordStop()
    {
        record_status = false;
        client_->StopRecorder();
    }

    carla::client::BlueprintLibrary::const_pointer GetBlueprint(const std::string& blueprint_name) 
    {
        return blueprint_library_->Find(blueprint_name);
    }

    void SpawnVehicle(const std::string& blueprint_name, 
                      const cg::Transform& transform) 
    {
        // std::cout << "1" << std::endl;
        auto bp = blueprint_library_->Find(blueprint_name);
        carla::traffic_manager::ActorPtr actor = world_->SpawnActor(*bp, transform);
        // std::cout << "2" << std::endl;
        vehicle_ = boost::static_pointer_cast<cc::Vehicle>(actor);
        // std::cout << "3" << std::endl;
    }

    std::vector<carla::geom::Transform> GetSpawnPoints()
    {
        carla::SharedPtr<carla::client::Map> map = world_->GetMap();
        return map->GetRecommendedSpawnPoints();
    }

    cg::Location MakeLocation(double x, double y, double z)
    {
        return cg::Location{x, y, z};
    }

    cg::Rotation MakeRotation(double r, double p, double y)
    {
        return cg::Rotation{r, p, y};
    }

    cg::Transform MakeTransform(const cg::Location& L, const cg::Rotation& R) const
    {
        return cg::Transform{
            L,
            R
        };
    }

    cg::Transform MakeTransform(double x, double y, double z, double R, double P, double Y) const
    {
        return cg::Transform{
            {x, y, z},
            {R, P, Y}
        };
    }

    cg::Transform MakeTransform(const cg::Rotation& R, const cg::Location& L) const
    {
        return cg::Transform{
            L,
            R
        };
    }
    std::vector<boost::shared_ptr<cc::Sensor>> GetSensors()
    {
        return sensors_;
    }

    //template <typename T>
    void AttachSensor(const std::string& blueprint_name, 
                      const cg::Transform& relative_transform,
                      const std::map<std::string, std::string>& attributes,
                      carla::client::Sensor::CallbackFunctionType callback)
    {
        //auto blueprint = GetBlueprint(blueprint_name);
        auto blueprint = blueprint_library_->Find(blueprint_name);

        auto mutable_blueprint = boost::const_pointer_cast<cc::ActorBlueprint>(blueprint);

        for (const auto& attribute : attributes) 
        {
            mutable_blueprint->SetAttribute(attribute.first, attribute.second);
        }

        carla::traffic_manager::ActorPtr  actor = world_->SpawnActor(*mutable_blueprint, relative_transform, vehicle_.get());
        auto sensor_ = boost::static_pointer_cast<cc::Sensor>(actor);
        sensor_->Listen(callback);
        sensors_.push_back(sensor_);
    }

    void ApplyVehicleControl(const cc::Vehicle::Control& control) 
    {
        vehicle_->ApplyControl(control);
    }

    void Run(float duration_sec) 
    {
        std::this_thread::sleep_for(std::chrono::duration<float>(duration_sec));
    }

    void Tick()
    {
        carla::time_duration t = carla::time_duration::seconds(30);
        world_->Tick(t);
    }

    void Destroy() 
    {
        for (const auto& sensor : sensors_) 
        {
            sensor->Destroy();
        }
        sensors_.clear();

        if (vehicle_) 
        {
            vehicle_->Destroy();
            vehicle_.reset();
        }
    }

private:
    boost::shared_ptr<cc::Client> client_;
    boost::shared_ptr<cc::World> world_;
    boost::shared_ptr<cc::BlueprintLibrary> blueprint_library_;
    boost::shared_ptr<cc::Vehicle> vehicle_;
    std::vector<boost::shared_ptr<cc::Sensor>> sensors_;
    bool record_status = false;


};

#endif // CARLA_CTL_H