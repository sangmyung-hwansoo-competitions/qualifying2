#ifndef SCOPEDCARLARECORDER_H
#define SCOPEDCARLARECORDER_H

#include <string>
#include <chrono>
#include <sstream>
#include <iomanip>
#include "carla/client/Client.h"
#include "carla_ctl.h"

class ScopedCarlaRecorder {
public:
    ScopedCarlaRecorder(CarlaCtl &ctl, const std::string &base_name) : _ctl(ctl), _path(base_name) {}
    ~ScopedCarlaRecorder() 
    {
        _ctl.RecordStop();
    }

    void StartRecording() 
    {
        std::string path = GenerateFilename(_path);
        _ctl.RecordStart(path);
    }

    std::string GenerateFilename(const std::string &base_name) 
    {
        std::stringstream ss;
        ss << base_name << ".log";
        return ss.str();
    }
    
private:
    CarlaCtl &_ctl;
    std::string _path;
};

#endif // SCOPEDCARLARECORDER_H
